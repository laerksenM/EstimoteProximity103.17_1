package dtu

object DeviceList {
    val deviceNames = mapOf("e24c134e34c78d991e60e33b8e06b528" to "510",
        "9581c32e6b1bf8d6687a2dc8f026d020" to "512",
        "5d36743f41b52abced6ac7ebb825d71f" to "511")
}




