package dtu.core

object CloudCredentials {
    const val APP_ID = "db3-3mn"
    const val APP_TOKEN = "5f35900302cfca5cda1456d6e682debf"

}