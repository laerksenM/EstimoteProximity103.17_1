package dtu.core

object Constants {
    //Firestore
    const val AGEGROUP= "agegroup"
    const val FIREBASETAG = "Firebase"
    const val ZONETAG = "zonetag"
    const val BEACONLOGTAG = "beacon"
}