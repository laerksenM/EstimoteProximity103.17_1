package dtu.core

object ZoneNavn {
    const val TAG510 = "510"
    const val TAG511 = "511"
    const val TAG512 = "512"

}