package dtu

object AgegroupData {
    val ageSample = listOf(
        Agegroup(
            "3 to 5"
        ),
        Agegroup(
            "6 to 9"
        ),
        Agegroup(
            "10 to 13"
        ),
        Agegroup(
            "14 to 17"
        )
    )
}