package dtu

enum class AttachmentKeys(val key: String) {
    DESCRIPTION("description")
}

