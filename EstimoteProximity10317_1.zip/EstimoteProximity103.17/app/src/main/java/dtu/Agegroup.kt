package dtu


data class Agegroup (
    var age: String? = null,
    var zonetag: String? = null
    )
