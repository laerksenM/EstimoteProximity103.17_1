package dtu

interface AgegroupRepository {
    fun getAgegroup()
}