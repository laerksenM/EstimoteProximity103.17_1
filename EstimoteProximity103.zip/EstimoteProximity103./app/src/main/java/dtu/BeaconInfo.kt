package dtu

data class BeaconInfo(val deviceID: String, val tag: String, val attachments: Map<String, String>)






