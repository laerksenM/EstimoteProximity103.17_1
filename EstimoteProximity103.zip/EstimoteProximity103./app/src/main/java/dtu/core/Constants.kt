package dtu.core

object Constants {
    //Firestore
    const val AGE= "age"
    const val FIREBASETAG = "Firebase"
}