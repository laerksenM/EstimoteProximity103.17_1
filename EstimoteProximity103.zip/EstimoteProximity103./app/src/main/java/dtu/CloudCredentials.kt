package dtu

object CloudCredentials {
    const val APP_ID = "gruppe3-7ae"
    const val APP_TOKEN = "0b90af4659575dbf64ba00b89ea6159b"
}